function ok() {
    const newElement = document.createElement('div');
    newElement.textContent = '설문조사 끝났습니다.';
    document.body.appendChild(newElement);
}